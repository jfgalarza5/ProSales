package Control;

//Se importa las librerias a utilizar
import com.mongodb.client.*;
import com.mongodb.client.MongoClients;
import java.io.*;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Conexion {
    //Url de que contiene la direccion y autentificacion del mongo Atlas
    private String Atlas="mongodb+srv://johngalarza:holamongo@cluster0.zjdlkp3.mongodb.net/?retryWrites=true&w=majority";
    private String localhost = "mongodb://localhost:27017";
    //Metodo que devuelve un MongoClient conectada a la base de datos
    public MongoClient crearConexion(){
        try{
            //MongoClient mongo=MongoClients.create(Atlas);
            MongoClient mongo=MongoClients.create(Atlas);
            return mongo;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Fallo la conexion con la base de datos");
        }
        return null;
    }
    
    public String baseName(){
        try{
            Scanner in = new Scanner(new File("Sistema/Base/empresa.txt"));
            String base = in.nextLine();
            in.close();
            return base;
        }catch(FileNotFoundException e){
        }
        return null;
    }
}