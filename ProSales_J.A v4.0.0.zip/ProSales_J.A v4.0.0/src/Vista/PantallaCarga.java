package Vista;

import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.swing.Timer;

public class PantallaCarga extends javax.swing.JFrame {

    public Color transparente;
    int delay;
    
    public PantallaCarga(int delay) {
        this.delay=delay;
        setUndecorated(true);
        initComponents();
        transparente = new Color(0,0,0,0);
        setLocationRelativeTo(null);
        setBackground(transparente);
        panel.setBackground(new Color(0,0,0,225));
        cargando.setBackground(transparente);
        progreso();
        
        setVisible(true);

        try {
            Thread.sleep(delay*1000);
        } catch (InterruptedException ex) {
        }

        dispose();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel = new javax.swing.JPanel();
        barra = new javax.swing.JProgressBar();
        jLabel1 = new javax.swing.JLabel();
        cargando = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panel.setBackground(new java.awt.Color(0, 0, 0));

        barra.setBackground(new java.awt.Color(255, 255, 255));
        barra.setForeground(new java.awt.Color(0, 0, 0));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icono/logo.png"))); // NOI18N

        cargando.setBackground(new java.awt.Color(51, 51, 51));
        cargando.setFont(new java.awt.Font("Segoe UI", 3, 11)); // NOI18N
        cargando.setForeground(new java.awt.Color(255, 255, 255));
        cargando.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icono/cargando.gif"))); // NOI18N
        cargando.setText("   Conectando a la Base de datos.....");
        cargando.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 0));
        jLabel2.setText("CodeLarza");

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLayout.createSequentialGroup()
                .addGap(104, 104, 104)
                .addComponent(barra, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(106, Short.MAX_VALUE))
            .addGroup(panelLayout.createSequentialGroup()
                .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelLayout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(cargando))
                    .addGroup(panelLayout.createSequentialGroup()
                        .addGap(125, 125, 125)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(38, 38, 38))
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLayout.createSequentialGroup()
                .addContainerGap(48, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(barra, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(cargando)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(29, 29, 29))
        );

        getContentPane().add(panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 380));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void progreso(){
        Timer tiempo = new Timer(delay*10, (ActionEvent e)->{
            barra.setValue(barra.getValue()+1);
            barra.setStringPainted(true);
            barra.setString("CARGANDO...  "+barra.getValue()+"%");
        });
        tiempo.start();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar barra;
    private javax.swing.JLabel cargando;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel panel;
    // End of variables declaration//GEN-END:variables
}
