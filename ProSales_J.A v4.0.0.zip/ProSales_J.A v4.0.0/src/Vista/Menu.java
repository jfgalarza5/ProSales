package Vista;

import Control.Conexion;
import Modelo.*;
import com.mongodb.client.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.bson.Document;

public class Menu extends javax.swing.JFrame{
    
    funcionalidades funcion = new funcionalidades();
    Conexion con = new Conexion();
    MongoClient mongo=con.crearConexion();
    MongoDatabase base = mongo.getDatabase(con.baseName());

    public Menu(){
        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        btnVolver.setVisible(false);
        fecha.setText(funcion.fechaHoy());
        tiposProdcutos();
        MongoCollection coleccion = base.getCollection("Empresa");
        MongoCursor<Document> cursor = coleccion.find().iterator();
        Document datosTienda = cursor.next();
        msjTienda.setText(datosTienda.get("Nombre").toString());
    }
    
    public void loginAdmin(){
        funcion.actualizarPanel(new AdminLogin());
    }
    
    public void cajero(){
        funcion.actualizarPanel(new Cajero());
    }
    
    public void tienda(){
        funcion.actualizarPanel(new TiendaDatos());
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        Menu = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnAdmin = new javax.swing.JButton();
        btnTienda = new javax.swing.JButton();
        btnCajero = new javax.swing.JButton();
        msjTienda = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        Menuhorizontal = new javax.swing.JPanel();
        btnVolver = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        btnCerrarSesion = new javax.swing.JLabel();
        Escritorio = new GradientPanel();
        fecha = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        soporte = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        txtTipos = new javax.swing.JLabel();
        tipo1 = new javax.swing.JLabel();
        tipo2 = new javax.swing.JLabel();
        tipo3 = new javax.swing.JLabel();
        tipo4 = new javax.swing.JLabel();
        tipo5 = new javax.swing.JLabel();
        tipo6 = new javax.swing.JLabel();
        tipo7 = new javax.swing.JLabel();
        tipo8 = new javax.swing.JLabel();
        tipo9 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema de Gestion de Tienda");
        setBackground(new java.awt.Color(255, 255, 255));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setExtendedState(6);
        setForeground(new java.awt.Color(51, 102, 255));

        Fondo.setBackground(new java.awt.Color(68, 69, 72));
        Fondo.setPreferredSize(new java.awt.Dimension(1020, 600));

        Menu.setBackground(new java.awt.Color(0, 0, 153));
        Menu.setPreferredSize(new java.awt.Dimension(270, 600));

        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icono/logo.png"))); // NOI18N

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(245, 2));
        jPanel2.setRequestFocusEnabled(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );

        btnAdmin.setBackground(new java.awt.Color(0, 51, 204));
        btnAdmin.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        btnAdmin.setForeground(new java.awt.Color(228, 228, 228));
        btnAdmin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icono/admin.png"))); // NOI18N
        btnAdmin.setText("     Administrador");
        btnAdmin.setToolTipText("Administra los Productos, Clientes y Credenciales del negocio.");
        btnAdmin.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        btnAdmin.setBorderPainted(false);
        btnAdmin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAdmin.setFocusable(false);
        btnAdmin.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAdmin.setIconTextGap(0);
        btnAdmin.setMargin(new java.awt.Insets(0, 14, 3, 14));
        btnAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminActionPerformed(evt);
            }
        });

        btnTienda.setBackground(new java.awt.Color(0, 51, 204));
        btnTienda.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        btnTienda.setForeground(new java.awt.Color(228, 228, 228));
        btnTienda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icono/tienda.png"))); // NOI18N
        btnTienda.setText("    Tienda");
        btnTienda.setToolTipText("Gestina los detalles de tu tienda como nombre, direccion, etc.");
        btnTienda.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        btnTienda.setBorderPainted(false);
        btnTienda.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnTienda.setFocusable(false);
        btnTienda.setHideActionText(true);
        btnTienda.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnTienda.setIconTextGap(0);
        btnTienda.setMargin(new java.awt.Insets(0, 14, 3, 14));
        btnTienda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTiendaActionPerformed(evt);
            }
        });

        btnCajero.setBackground(new java.awt.Color(0, 51, 204));
        btnCajero.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        btnCajero.setForeground(new java.awt.Color(228, 228, 228));
        btnCajero.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icono/cajero.png"))); // NOI18N
        btnCajero.setText("     Cajero");
        btnCajero.setToolTipText("Realiza Busqueda, Venta y Facturación de los productos de una manera eficaz.");
        btnCajero.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        btnCajero.setBorderPainted(false);
        btnCajero.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCajero.setFocusable(false);
        btnCajero.setHideActionText(true);
        btnCajero.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnCajero.setIconTextGap(0);
        btnCajero.setMargin(new java.awt.Insets(0, 14, 3, 14));
        btnCajero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCajeroActionPerformed(evt);
            }
        });

        msjTienda.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        msjTienda.setForeground(new java.awt.Color(255, 255, 255));
        msjTienda.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        msjTienda.setText("Tienda xxxxxxx");

        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout MenuLayout = new javax.swing.GroupLayout(Menu);
        Menu.setLayout(MenuLayout);
        MenuLayout.setHorizontalGroup(
            MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(285, 285, 285))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MenuLayout.createSequentialGroup()
                .addGroup(MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnAdmin, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCajero, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnTienda, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(276, 276, 276))
            .addGroup(MenuLayout.createSequentialGroup()
                .addGroup(MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(MenuLayout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(MenuLayout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(msjTienda, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        MenuLayout.setVerticalGroup(
            MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MenuLayout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addComponent(logo)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(btnAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnCajero, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnTienda, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(msjTienda, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        Menuhorizontal.setBackground(new java.awt.Color(0, 0, 255));

        btnVolver.setFont(new java.awt.Font("Cambria", 0, 13)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icono/Volver.png"))); // NOI18N
        btnVolver.setText("  Regresar");
        btnVolver.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnVolverMouseClicked(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(30, 30, 30));
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("jLabel1");

        btnCerrarSesion.setBackground(new java.awt.Color(255, 255, 255));
        btnCerrarSesion.setFont(new java.awt.Font("Cambria", 0, 13)); // NOI18N
        btnCerrarSesion.setForeground(new java.awt.Color(255, 255, 255));
        btnCerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icono/CerrarSesion.png"))); // NOI18N
        btnCerrarSesion.setToolTipText("Cerrar Sesión");
        btnCerrarSesion.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCerrarSesion.setName(" Cerrar Sesión"); // NOI18N
        btnCerrarSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCerrarSesionMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout MenuhorizontalLayout = new javax.swing.GroupLayout(Menuhorizontal);
        Menuhorizontal.setLayout(MenuhorizontalLayout);
        MenuhorizontalLayout.setHorizontalGroup(
            MenuhorizontalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MenuhorizontalLayout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(btnVolver, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(44, 44, 44)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(240, 240, 240)
                .addComponent(btnCerrarSesion)
                .addGap(145, 145, 145))
        );
        MenuhorizontalLayout.setVerticalGroup(
            MenuhorizontalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MenuhorizontalLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(MenuhorizontalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCerrarSesion, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
                    .addComponent(jLabel1)
                    .addComponent(btnVolver, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(23, 23, 23))
        );

        btnCerrarSesion.getAccessibleContext().setAccessibleName("  Cerrar Sesión");
        btnCerrarSesion.getAccessibleContext().setAccessibleDescription("  Cerrar Sesión");

        fecha.setBackground(new java.awt.Color(0, 0, 255));
        fecha.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fecha.setForeground(new java.awt.Color(0, 0, 204));
        fecha.setText("Hoy es xx de xxxxx del xxxx ");

        jLabel13.setForeground(new java.awt.Color(153, 153, 153));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel13.setText("Bienvenido al programa ProSales. Con este programa, puedes realizar las ");

        jLabel14.setForeground(new java.awt.Color(153, 153, 153));
        jLabel14.setText("siguientes acciones: ");

        jLabel15.setForeground(new java.awt.Color(153, 153, 153));
        jLabel15.setText("-   Registrar, consultar, modificar y eliminar productos existentes en tu tienda fisica.");

        jLabel16.setForeground(new java.awt.Color(153, 153, 153));
        jLabel16.setText("-  Administrar el negocio como Administrador y Cajero");

        jLabel17.setForeground(new java.awt.Color(153, 153, 153));
        jLabel17.setText("Para empezar, elige una opción del menú principal. Si necesitas ayuda o tienes problemas ");

        jLabel18.setForeground(new java.awt.Color(153, 153, 153));
        jLabel18.setText("no dudes en contactar al soporte técnico. Esperamos que disfrutes de este programa y ");

        jLabel19.setForeground(new java.awt.Color(153, 153, 153));
        jLabel19.setText("que te sea útil para tu negocio.");

        soporte.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        soporte.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icono/soporte.png"))); // NOI18N
        soporte.setText("Soporte");
        soporte.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                soporteMouseClicked(evt);
            }
        });

        jLabel2.setText(" ");

        txtTipos.setText("Productos disponibles:");

        tipo1.setForeground(new java.awt.Color(153, 153, 153));
        tipo1.setText("jLabel3");

        tipo2.setForeground(new java.awt.Color(153, 153, 153));
        tipo2.setText("jLabel4");

        tipo3.setForeground(new java.awt.Color(153, 153, 153));
        tipo3.setText("jLabel5");

        tipo4.setForeground(new java.awt.Color(153, 153, 153));
        tipo4.setText("jLabel6");

        tipo5.setForeground(new java.awt.Color(153, 153, 153));
        tipo5.setText("jLabel7");

        tipo6.setForeground(new java.awt.Color(153, 153, 153));
        tipo6.setText("jLabel8");

        tipo7.setForeground(new java.awt.Color(153, 153, 153));
        tipo7.setText("jLabel9");

        tipo8.setForeground(new java.awt.Color(153, 153, 153));
        tipo8.setText("jLabel10");

        tipo9.setForeground(new java.awt.Color(153, 153, 153));
        tipo9.setText("jLabel11");

        jLabel3.setText("   ");

        javax.swing.GroupLayout EscritorioLayout = new javax.swing.GroupLayout(Escritorio);
        Escritorio.setLayout(EscritorioLayout);
        EscritorioLayout.setHorizontalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EscritorioLayout.createSequentialGroup()
                .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(EscritorioLayout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(EscritorioLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(46, 46, 46)
                        .addComponent(soporte, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(EscritorioLayout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator3)
                            .addComponent(jSeparator4))
                        .addGap(7, 7, 7)))
                .addGap(94, 94, 94))
            .addGroup(EscritorioLayout.createSequentialGroup()
                .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(EscritorioLayout.createSequentialGroup()
                        .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(69, 69, 69)
                                .addComponent(jLabel14))
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(79, 79, 79)
                                .addComponent(jLabel15))
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(79, 79, 79)
                                .addComponent(jLabel16))
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(69, 69, 69)
                                .addComponent(jLabel17))
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(69, 69, 69)
                                .addComponent(jLabel18))
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(69, 69, 69)
                                .addComponent(jLabel19)))
                        .addGap(14, 14, 14)
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE))
                    .addGroup(EscritorioLayout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49)))
                .addGap(34, 34, 34)
                .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tipo1)
                    .addComponent(tipo2)
                    .addComponent(tipo3)
                    .addComponent(tipo4)
                    .addComponent(tipo5)
                    .addComponent(tipo6)
                    .addComponent(tipo7)
                    .addComponent(tipo8)
                    .addComponent(tipo9)
                    .addComponent(txtTipos, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        EscritorioLayout.setVerticalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EscritorioLayout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(EscritorioLayout.createSequentialGroup()
                        .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(jLabel13)
                                .addGap(7, 7, 7))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EscritorioLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtTipos)
                                .addGap(18, 18, 18)))
                        .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addComponent(jLabel14))
                            .addComponent(tipo1))
                        .addGap(7, 7, 7)
                        .addComponent(tipo2)
                        .addGap(11, 11, 11)
                        .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15)
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(tipo3)))
                        .addGap(1, 1, 1)
                        .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel16)
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addComponent(tipo4)))
                        .addGap(14, 14, 14)
                        .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addComponent(jLabel17))
                            .addComponent(tipo5))
                        .addGap(4, 4, 4)
                        .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18)
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(tipo6)))
                        .addGap(11, 11, 11)
                        .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19)
                            .addGroup(EscritorioLayout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(tipo7)))
                        .addGap(14, 14, 14)
                        .addComponent(tipo8)
                        .addGap(14, 14, 14)
                        .addComponent(tipo9)
                        .addGap(44, 44, 44))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EscritorioLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(soporte)))
        );

        javax.swing.GroupLayout FondoLayout = new javax.swing.GroupLayout(Fondo);
        Fondo.setLayout(FondoLayout);
        FondoLayout.setHorizontalGroup(
            FondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FondoLayout.createSequentialGroup()
                .addComponent(Menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(FondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Menuhorizontal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Escritorio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        FondoLayout.setVerticalGroup(
            FondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Menu, javax.swing.GroupLayout.DEFAULT_SIZE, 682, Short.MAX_VALUE)
            .addGroup(FondoLayout.createSequentialGroup()
                .addComponent(Menuhorizontal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(Escritorio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, 1084, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, 682, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminActionPerformed
        loginAdmin();
    }//GEN-LAST:event_btnAdminActionPerformed

    private void btnTiendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTiendaActionPerformed
        tienda();
    }//GEN-LAST:event_btnTiendaActionPerformed

    private void btnVolverMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVolverMouseClicked

    }//GEN-LAST:event_btnVolverMouseClicked

    private void soporteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_soporteMouseClicked
        JOptionPane.showMessageDialog(null, "            SOPORTE TECNICO \n\n Contacto: 0980098210 \n E-mail: johngalarza1970@gmail.com \n\nLamentamos los inconvenientes\n                  JGSystem","NO DUDE EN CONTACTARNOS!!",JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_soporteMouseClicked

    private void btnCajeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCajeroActionPerformed
        cajero();
    }//GEN-LAST:event_btnCajeroActionPerformed

    private void btnCerrarSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCerrarSesionMouseClicked
        this.dispose();
        mongo.close();
        funcion.borrarArchivo("Sistema/Base/empresa.txt");
        new Login();
    }//GEN-LAST:event_btnCerrarSesionMouseClicked
    
    public void tiposProdcutos(){
        MongoCollection coleccion = base.getCollection("TipoProducto");
        MongoCursor<Document> cursor = coleccion.find().cursor();
        Document tipo = cursor.next();
        ArrayList<String> lista = new ArrayList<>();
        FindIterable<Document> listKeys = coleccion.find();
        Set<String> keys = new HashSet<>();
        for(Document key:listKeys){
            keys.addAll(key.keySet());
        }
        for(String indice:keys){
            if(!indice.equals("_id")){
                lista.add(indice);
                
            }
        }
        tipo1.setText(lista.get(0)+": "+tipo.getInteger(lista.get(0)));
        tipo2.setText(lista.get(1)+": "+tipo.getInteger(lista.get(1)));
        tipo3.setText(lista.get(2)+": "+tipo.getInteger(lista.get(2)));
        tipo4.setText(lista.get(3)+": "+tipo.getInteger(lista.get(3)));
        tipo5.setText(lista.get(4)+": "+tipo.getInteger(lista.get(4)));
        tipo6.setText(lista.get(5)+": "+tipo.getInteger(lista.get(5)));
        tipo7.setText(lista.get(6)+": "+tipo.getInteger(lista.get(6)));
        tipo8.setText(lista.get(7)+": "+tipo.getInteger(lista.get(7)));
        tipo9.setText(lista.get(8)+": "+tipo.getInteger(lista.get(8)));
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JPanel Escritorio;
    private javax.swing.JPanel Fondo;
    private javax.swing.JPanel Menu;
    private javax.swing.JPanel Menuhorizontal;
    public static javax.swing.JButton btnAdmin;
    public static javax.swing.JButton btnCajero;
    public static javax.swing.JLabel btnCerrarSesion;
    public static javax.swing.JButton btnTienda;
    public static javax.swing.JLabel btnVolver;
    private javax.swing.JLabel fecha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel msjTienda;
    private javax.swing.JLabel soporte;
    private javax.swing.JLabel tipo1;
    private javax.swing.JLabel tipo2;
    private javax.swing.JLabel tipo3;
    private javax.swing.JLabel tipo4;
    private javax.swing.JLabel tipo5;
    private javax.swing.JLabel tipo6;
    private javax.swing.JLabel tipo7;
    private javax.swing.JLabel tipo8;
    private javax.swing.JLabel tipo9;
    private javax.swing.JLabel txtTipos;
    // End of variables declaration//GEN-END:variables
}
