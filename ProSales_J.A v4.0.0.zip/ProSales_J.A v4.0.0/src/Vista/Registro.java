package Vista;

import Control.Conexion;
import Modelo.funcionalidades;
import com.mongodb.client.*;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import javax.imageio.ImageIO;
import javax.swing.*;
import org.bson.Document;

public class Registro extends javax.swing.JFrame {

    funcionalidades tool = new funcionalidades();
    Conexion con = new Conexion();
    MongoClient mongo = con.crearConexion();
    MongoDatabase base;
    
    public Registro() {
        setUndecorated(true);
        initComponents();
        iconLogo.setIcon(new ImageIcon("Sistema/Logo/defaultlogo.png"));
        setLocationRelativeTo(null);
        setVisible(true);
        validarEmpresa();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        txtNombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtTelf = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtUbicacion = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btnLogo = new javax.swing.JButton();
        iconLogo = new javax.swing.JLabel();
        txtSesion = new javax.swing.JLabel();
        btnRegistrar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtRepeatPass = new javax.swing.JPasswordField();
        msjContraseña = new javax.swing.JLabel();
        txtPass = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtNombre.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 204)));
        jPanel2.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 140, 196, -1));

        jLabel1.setText("Nombre:");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, -1, -1));

        jLabel4.setText("E-mail:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, -1, -1));

        txtEmail.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 204)));
        jPanel2.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, 196, -1));

        jLabel5.setText("Telf:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 240, -1, -1));

        txtTelf.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 204)));
        txtTelf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTelfKeyReleased(evt);
            }
        });
        jPanel2.add(txtTelf, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 240, 196, -1));

        jLabel6.setText("Ciudad:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 280, -1, 43));

        txtUbicacion.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 204)));
        jPanel2.add(txtUbicacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 290, 196, -1));

        jLabel3.setText("Logo:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 140, -1, -1));

        btnLogo.setText("Buscar");
        btnLogo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, java.awt.Color.lightGray, null, null));
        btnLogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoActionPerformed(evt);
            }
        });
        jPanel2.add(btnLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 130, 70, 40));

        iconLogo.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jPanel2.add(iconLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 120, 150, 90));

        txtSesion.setForeground(new java.awt.Color(0, 0, 255));
        txtSesion.setText("¿Ya registraste tu negocio? Inicia Sesion");
        txtSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtSesionMouseClicked(evt);
            }
        });
        jPanel2.add(txtSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 440, -1, -1));

        btnRegistrar.setBackground(new java.awt.Color(51, 51, 255));
        btnRegistrar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegistrar.setForeground(new java.awt.Color(255, 255, 255));
        btnRegistrar.setText("Registrar");
        btnRegistrar.setBorder(null);
        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });
        jPanel2.add(btnRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 380, 156, 38));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 28)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Registre su Negocio");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 710, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagen/degradadoAzul.jpg"))); // NOI18N
        jLabel10.setText("jLabel10");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 780, 90));

        jLabel7.setText("Contraseña:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 230, -1, 43));

        jLabel11.setText("Repita Contraseña:");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 290, -1, 20));

        txtRepeatPass.setToolTipText("");
        txtRepeatPass.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 204)));
        txtRepeatPass.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtRepeatPassKeyReleased(evt);
            }
        });
        jPanel2.add(txtRepeatPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 290, 164, -1));

        msjContraseña.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        msjContraseña.setForeground(new java.awt.Color(255, 0, 0));
        msjContraseña.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        msjContraseña.setText(" ");
        jPanel2.add(msjContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 330, 190, -1));

        txtPass.setToolTipText("");
        txtPass.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 204)));
        jPanel2.add(txtPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 240, 164, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 704, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        String nombre = txtNombre.getText();
        String email = txtEmail.getText();
        String telf = txtTelf.getText();
        String ciudad = txtUbicacion.getText();
        String repeatPass = String.valueOf(txtRepeatPass.getPassword());
        String Pass = String.valueOf(txtPass.getPassword());
        
        if(nombre.equals("")||email.equals("")||telf.equals("")||ciudad.equals("")||Pass.equals("")){
            JOptionPane.showMessageDialog(null, "Rellene todos los datos");
            return;
        }
        if(!repeatPass.equals(Pass)){
            JOptionPane.showMessageDialog(null, "Las contraseñas no son iguales");
            return;
        }
        if(tool.isValidEmail(txtEmail.getText())){
            String baseName = nombre.replaceAll("\\s", "");
            MongoIterable<String> databaseNames = mongo.listDatabaseNames();
            MongoCursor<String> cursor = databaseNames.cursor();
            while(cursor.hasNext()){
                if(baseName.equals(cursor.next())){
                    JOptionPane.showMessageDialog(null,"Ya hay un registro con ese nombre, porfavor inicie sesion");
                    return;
                }
            }
            tool.archivoTxt("Sistema/Base/empresa.txt", baseName);
            MongoDatabase base = mongo.getDatabase(con.baseName());
            MongoCollection<Document> coleccion = base.getCollection("Empresa");
            Document documento = new Document();
            documento.append("Nombre", nombre).append("Email", email).append("Telf", telf).append("Ciudad", ciudad).append("Pass", Pass);
            coleccion.insertOne(documento);
            MongoCollection<Document> credencial = base.getCollection("Credencial");
            Document credenciales = new Document();
            credenciales.append("User", "Admin").append("Pass", "Admin");
            credencial.insertOne(credenciales);
            AgregartiposProducto();
            JOptionPane.showMessageDialog(null, "Se registro su negocio con exito");
            iniciar();
            this.dispose();
        }else{
            JOptionPane.showMessageDialog(null, "Direccion Email no valida");
        }
    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void txtSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSesionMouseClicked
        new Login();
        dispose();
    }//GEN-LAST:event_txtSesionMouseClicked

    private void btnLogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoActionPerformed
        JFileChooser escogerArchivo = new JFileChooser();
        int result = escogerArchivo.showOpenDialog(null);
        if(result==JFileChooser.APPROVE_OPTION){
            File file = escogerArchivo.getSelectedFile();
            tool.copiarPegar(file.getAbsolutePath(),"Sistema/Logo/logo.png" );
            try {
                BufferedImage logo = ImageIO.read(new File("Sistema/Logo/logo.png"));
                double dimension=75/(double)logo.getHeight();
                iconLogo.setIcon(new ImageIcon(tool.redimensionar(logo, dimension)));
            } catch (IOException ex) {
            }
        }
    }//GEN-LAST:event_btnLogoActionPerformed

    private void txtTelfKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTelfKeyReleased
        String telf=txtTelf.getText();
        if(!tool.isANumber(telf)&&!telf.equals("")){
            txtTelf.setText("");
        }
    }//GEN-LAST:event_txtTelfKeyReleased

    private void txtRepeatPassKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtRepeatPassKeyReleased
        String repeatPass = String.valueOf(txtRepeatPass.getPassword());
        String Pass = String.valueOf(txtPass.getPassword());
        if(repeatPass.isEmpty()){
            if(!repeatPass.equals(Pass)){
                msjContraseña.setForeground(Color.red);
                msjContraseña.setText("Las contraseñas no son iguales");
            }else{
                msjContraseña.setForeground(Color.GREEN);
                msjContraseña.setText("Las contraseñas son iguales");
            }
        }else{
            msjContraseña.setText("");
        }
    }//GEN-LAST:event_txtRepeatPassKeyReleased
    
    public void validarEmpresa(){
        try {
            Scanner in = new Scanner(new File("Sistema/Base/empresa.txt"));
            if(!in.hasNext()){
                return;
            }else{
                in.close();
                dispose();
                iniciar();
            }
        } catch (FileNotFoundException ex) {
            return;
        }
    }
    
    public void AgregartiposProducto(){
        Document tiposProducto = new Document();
        MongoCollection<Document> coleccion = base.getCollection("TipoProducto");
        tiposProducto.append("Productos Frescos", 0)
                .append("Alimentación", 0)
                .append("Bebidas", 0)
                .append("Cuidado Personal", 0)
                .append("Electrodomésticos", 0)
                .append("Utiles Escolares", 0)
                .append("Ropa y Hogar", 0)
                .append("Salud y Bienestar", 0)
                .append("Otros", 0);
        coleccion.insertOne(tiposProducto);
    }
    
    public void iniciar(){
        mongo.close();
        Menu menu = new Menu();
        //Se habilita la visibilidad del formulario
        menu.setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogo;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JLabel iconLogo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel msjContraseña;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JPasswordField txtPass;
    private javax.swing.JPasswordField txtRepeatPass;
    private javax.swing.JLabel txtSesion;
    private javax.swing.JTextField txtTelf;
    private javax.swing.JTextField txtUbicacion;
    // End of variables declaration//GEN-END:variables
}
