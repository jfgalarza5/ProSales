package Vista;

import Control.Conexion;
import Modelo.Cajero;
import Modelo.funcionalidades;
import static Vista.Menu.*;
import com.mongodb.client.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.*;
import javax.swing.table.*;
import org.bson.Document;

public class CajeroVenta extends javax.swing.JPanel {
    
    Cajero cajero = new Cajero();
    funcionalidades funcion=new funcionalidades();
    Socket clientSocket;
    ServerSocket serverSocket;
    DefaultTableModel productos;
    String [] titulos =new String[]{"Codigo","Producto","Precio"};
    Conexion con = new Conexion();
    MongoClient mongo = con.crearConexion();
    MongoDatabase base = mongo.getDatabase(con.baseName());
    MongoCollection coleccion = base.getCollection("Producto");
    JTable Tabla=new JTable(null,titulos);
    JPopupMenu menu = new JPopupMenu();
    
    public CajeroVenta() {
        initComponents();
        obtenerProductos();
        TablaHeader();
        fuentes();
        btnVolver.setVisible(true);
        btnVolver.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnVolverMouseClicked(evt);
            }
        });
        Tabla.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent evt){
                TablaClicked(evt);
            }
        });
        btnCajero.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent evt){
                btnCajero(evt);
            }
        });
        btnAdmin.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent evt){
                btnAdmin(evt);
            }
        });
        btnTienda.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent evt){
                btnTienda(evt);
            }
        });
        java.awt.Toolkit.getDefaultToolkit().addAWTEventListener(
        event -> {
            if (event instanceof MouseEvent) {
                MouseEvent mouseEvent = (MouseEvent) event;
                    if (mouseEvent.getID() == MouseEvent.MOUSE_CLICKED && mouseEvent.getButton() == MouseEvent.BUTTON1) {
                        Point punto = mouseEvent.getLocationOnScreen();
                        try{
                            if(menu.getLocationOnScreen()!=punto){
                                menu.setVisible(false);
                            }
                        }catch(Exception e){}
                    }
            }
        },java.awt.AWTEvent.MOUSE_EVENT_MASK);
    }
    
    public void btnVolverMouseClicked(java.awt.event.MouseEvent evt){
        cerrarServer();
        menu.setVisible(false);
        funcion.actualizarPanel(new Vista.Cajero());
    }
    
    public void fuentes(){
        try{
            File font = new File("Sistema/Fuente/digital-dream/DigitaldreamFatNarrow.ttf");
            Font digital = Font.createFont(Font.TRUETYPE_FONT, font).deriveFont(0,24);
            txtPrecio.setFont(digital);
            txtSignoDollar.setFont(digital);
        }catch(Exception e){
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaFactura = new javax.swing.JTable();
        txtProductoFact = new javax.swing.JTextField();
        txtCantidadFact = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnAgregar = new javax.swing.JButton();
        btnVenta = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtCodigoFact = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        txtSignoDollar = new javax.swing.JLabel();
        txtPrecio = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnConectar = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnActualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        imagen = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        TablaFactura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Producto", "Precio Uni.", "Cantidad", "Precio Final"
            }
        ));
        TablaFactura.setToolTipText("");
        TablaFactura.setGridColor(new java.awt.Color(0, 0, 0));
        TablaFactura.setSelectionBackground(new java.awt.Color(102, 102, 102));
        TablaFactura.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TablaFactura.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaFacturaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaFactura);

        txtProductoFact.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 255)));
        txtProductoFact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProductoFactActionPerformed(evt);
            }
        });
        txtProductoFact.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtProductoFactKeyReleased(evt);
            }
        });

        txtCantidadFact.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 255)));
        txtCantidadFact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadFactActionPerformed(evt);
            }
        });
        txtCantidadFact.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCantidadFactKeyReleased(evt);
            }
        });

        jLabel1.setText("Producto:");
        jLabel1.setToolTipText("");

        jLabel2.setText("Cantidad:");
        jLabel2.setToolTipText("");

        btnAgregar.setBackground(new java.awt.Color(0, 0, 204));
        btnAgregar.setForeground(new java.awt.Color(255, 255, 255));
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnVenta.setBackground(new java.awt.Color(0, 0, 204));
        btnVenta.setForeground(new java.awt.Color(255, 255, 255));
        btnVenta.setText("Realizar Venta");
        btnVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVentaActionPerformed(evt);
            }
        });

        jLabel4.setText("Prec. Total:");

        jLabel6.setText("Codigo:");
        jLabel6.setToolTipText("");

        txtCodigoFact.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 255)));
        txtCodigoFact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoFactActionPerformed(evt);
            }
        });
        txtCodigoFact.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCodigoFactKeyReleased(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        txtSignoDollar.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        txtSignoDollar.setForeground(new java.awt.Color(51, 255, 51));
        txtSignoDollar.setText("$");

        txtPrecio.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        txtPrecio.setForeground(new java.awt.Color(51, 255, 51));
        txtPrecio.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        txtPrecio.setText("0");
        txtPrecio.setToolTipText("");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(txtPrecio, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtSignoDollar)
                .addGap(21, 21, 21))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPrecio)
                    .addComponent(txtSignoDollar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel5.setText("  ");

        btnConectar.setBackground(new java.awt.Color(0, 0, 204));
        btnConectar.setForeground(new java.awt.Color(255, 255, 255));
        btnConectar.setText("Conectar Lector ProSales");
        btnConectar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConectarActionPerformed(evt);
            }
        });

        jLabel9.setText(" ");

        jLabel3.setText("       ");

        btnActualizar.setBackground(new java.awt.Color(0, 0, 204));
        btnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(0, 0, 204));
        btnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 204));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Porfavor ingrese los detalles de su producto");

        imagen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        imagen.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Imagen del Producto");

        jLabel8.setText("      ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(btnAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(btnActualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(txtCodigoFact, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel2)
                                    .addGap(19, 19, 19)
                                    .addComponent(txtCantidadFact))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtProductoFact, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(btnVenta, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE))
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(btnConectar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(21, 21, 21))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(39, 39, 39)))
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                .addGap(10, 10, 10))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addGap(12, 12, 12)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addGap(20, 20, 20))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel10)
                                .addGap(18, 18, 18)
                                .addComponent(btnConectar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(txtCodigoFact, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(29, 29, 29)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(txtProductoFact, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(20, 20, 20)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(txtCantidadFact, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(73, 73, 73)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(7, 7, 7))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        String ID = txtCodigoFact.getText();
        String producto = txtProductoFact.getText();
        String cant = txtCantidadFact.getText();
        if(!ID.isEmpty()&&!producto.isEmpty()&&!cant.isEmpty()){
            if(!validarProducto()){
                JOptionPane.showMessageDialog(null, "Producto no encontrado en su base de datos");
                return;
            }
            if(validarRepetidos(producto,ID)){
                JOptionPane.showMessageDialog(null, "Ya se ingreso este producto");
                txtCodigoFact.setText("");
                txtProductoFact.setText("");
                txtCantidadFact.setText("");
                menu.setVisible(false);
                return;
            }
            cajero.agregarProducto();
            actualizarPrecio();
            centrarTabla();
            menu.setVisible(false);
            txtCodigoFact.setText("");
            txtProductoFact.setText("");
            txtCantidadFact.setText("");
        }else{
            JOptionPane.showMessageDialog(null, "Rellena todos los campos");
        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVentaActionPerformed
        JOptionPane.showMessageDialog(null, "Venta realizada "+txtPrecio.getText()+" $");
        funcion.actualizarPanel(new CajeroCliente(cajero,Double.parseDouble(txtPrecio.getText())));
        menu.setVisible(false);
    }//GEN-LAST:event_btnVentaActionPerformed

    private void TablaFacturaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaFacturaMouseClicked
        int fila=TablaFactura.getSelectedRow();
        String codigo=TablaFactura.getValueAt(fila, 0).toString();
        String producto=TablaFactura.getValueAt(fila, 1).toString();
        String cantidad=TablaFactura.getValueAt(fila, 3).toString();
        new Thread(()->{
            imagen.setIcon(new ImageIcon(funcion.imagenProducto(TablaFactura.getValueAt(fila, 1).toString(), 100)));
        }).start();
        txtCodigoFact.setText(codigo);
        txtProductoFact.setText(producto);
        txtCantidadFact.setText(cantidad);
    }//GEN-LAST:event_TablaFacturaMouseClicked

    private void txtCantidadFactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadFactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCantidadFactActionPerformed

    private void txtCodigoFactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoFactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoFactActionPerformed

    private void txtProductoFactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProductoFactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtProductoFactActionPerformed

    private void btnConectarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConectarActionPerformed
        cerrarServer();
        new Thread(()->{
            ConectarLector lector = new ConectarLector();
            while(lector.isRunning){
                try{
                    Thread.sleep(2000);
                }catch (InterruptedException ex){
                }
            }
            server();
        }).start();
    }//GEN-LAST:event_btnConectarActionPerformed

    private void txtCodigoFactKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodigoFactKeyReleased
        String codigo=txtCodigoFact.getText();
        if(!codigo.equals("")){
            if(funcion.isANumber(codigo)){
                buscarProducto();
            }else{
                txtCodigoFact.setText("");
                menu.setVisible(false);
            }
        }
    }//GEN-LAST:event_txtCodigoFactKeyReleased

    private void txtProductoFactKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtProductoFactKeyReleased
        buscarProducto();
    }//GEN-LAST:event_txtProductoFactKeyReleased

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        int fila=TablaFactura.getSelectedRow();
        String codigo=txtCodigoFact.getText();
        String producto=txtProductoFact.getText();
        String cantidad=txtCantidadFact.getText();
        double precio=Double.parseDouble(TablaFactura.getValueAt(fila, 2).toString());
        if(!codigo.isEmpty()&&!producto.isEmpty()&&!cantidad.isEmpty()){
            if(!validarProducto()){
                JOptionPane.showMessageDialog(null, "Producto no encontrado en su base de datos");
                return;
            }
            if(validarRepetidosActualizar()){
                JOptionPane.showMessageDialog(null, "Ya se ingreso este producto");
                return;
            }
            TablaFactura.setValueAt(codigo, fila, 0);
            TablaFactura.setValueAt(producto, fila, 1);
            TablaFactura.setValueAt(cantidad, fila, 3);
            TablaFactura.setValueAt(precio*Double.parseDouble(cantidad), fila, 4);
            actualizarPrecio();
        }else{
            JOptionPane.showMessageDialog(null, "Rellena todos los campos");
        }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = TablaFactura.getSelectedRow();
        DefaultTableModel modelo = (DefaultTableModel) TablaFactura.getModel();
        modelo.removeRow(fila);
        actualizarPrecio();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void txtCantidadFactKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidadFactKeyReleased
        String cantidad = txtCantidadFact.getText();
        if(!cantidad.equals("")&&!funcion.isANumberNatural(cantidad)){
            txtCantidadFact.setText("");
        }        
    }//GEN-LAST:event_txtCantidadFactKeyReleased
    
    public void TablaClicked(MouseEvent evt){
        int fila = Tabla.getSelectedRow();
        txtCodigoFact.setText(Tabla.getValueAt(fila, 0).toString());
        txtProductoFact.setText(Tabla.getValueAt(fila, 1).toString());
        new Thread(()->{
            imagen.setIcon(new ImageIcon(funcion.imagenProducto(Tabla.getValueAt(fila, 1).toString(), 150)));
        }).start();
        menu.setVisible(false);
    }
    
    public void btnCajero(MouseEvent evt){
        cerrarServer();
        menu.setVisible(false);
        funcion.actualizarPanel(new Vista.Cajero());
    }
    
    public void btnAdmin(MouseEvent evt){
        cerrarServer();
        menu.setVisible(false);
        funcion.actualizarPanel(new AdminLogin());
    }
    
    public void btnTienda(MouseEvent evt){
        cerrarServer();
        menu.setVisible(false);
        funcion.actualizarPanel(new TiendaDatos());
    }
    
    public boolean validarProducto(){
        Document producto = new Document();
        producto.append("ID", txtCodigoFact.getText())
                .append("Producto", txtProductoFact.getText());
        MongoCursor<Document> cursor = coleccion.find(producto).cursor();
        try{
            cursor.next();
            return true;
        }catch(Exception e){
        }
        return false;
    }
    
    public boolean validarRepetidos(String nombre, String ID){
        for(int i=0;i<TablaFactura.getRowCount();i++){
            String codigo=TablaFactura.getValueAt(i, 0).toString();
            String producto=TablaFactura.getValueAt(i, 1).toString();
            if(codigo.equals(ID) || producto.equals(nombre)){
                return true;
            }
        }
        return false;
    }
    
    public boolean validarRepetidosActualizar(){
        for(int i=0;i<TablaFactura.getRowCount();i++){
            String codigo=TablaFactura.getValueAt(i, 0).toString();
            String producto=TablaFactura.getValueAt(i, 1).toString();
            String cantidad=TablaFactura.getValueAt(i, 3).toString();
            if(codigo.equals(txtCodigoFact.getText()) && producto.equals(txtProductoFact.getText()) && cantidad.equals(txtCantidadFact.getText())){
                return true;
            }
        }
        return false;
    }
    
    public void TablaHeader(){
        TablaFactura.getTableHeader().setBackground(Color.BLUE);
        TablaFactura.getTableHeader().setForeground(Color.white);
    }
    
    public void cerrarServer(){
        try{
            if(clientSocket!=null){
                System.out.println("Socket cerrado");
                clientSocket.close();
            }
            if(serverSocket!=null){
                System.out.println("Server cerrado");
                serverSocket.close();
            }
        }catch(IOException x){
        }
    }
    
    public void server(){
        int portNumber = 12345; // Puedes cambiar este número de puerto según tus necesidades
        try{
            serverSocket = new ServerSocket(portNumber);
            while(true){
                Socket clientSocket = serverSocket.accept();
                new Thread(() -> handleConnection(clientSocket)).start();
            }
        } catch (IOException e){
        }
    }
    
    public void actualizarPrecio(){
        double precio = 0;
        for(int i=0;i<TablaFactura.getRowCount();i++){
            precio += Double.parseDouble(TablaFactura.getValueAt(i, 4).toString());
        }
        precio=funcion.redondear(precio, 2);
        txtPrecio.setText(String.valueOf(precio));
    }
    
    private void handleConnection(Socket clientSocket){
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {
            String codigo;
            int cont=0;
            while ((codigo=reader.readLine())!=null){
                cont++;
                if(cont!=1){
                    System.out.println("Mensaje recibido: "+codigo);
                    agregarProductosLector(codigo);
                    cont=0;
                }
            }
        } catch (IOException e) {
        }
    }
    
    public void agregarProductosLector(String codigo){
        Document documento = new Document("ID",codigo);
        MongoCursor<Document> cursor = coleccion.find(documento).iterator();
        try{
            Document producto=cursor.next();
            String nombre=producto.getString("Producto");
            if(validarRepetidos(nombre, codigo)){
                JOptionPane.showMessageDialog(null, "Ya se ingreso este producto");
                return;
            }
            double precio=Double.parseDouble(producto.getString("Precio"));
            boolean bandera=true;
            String cantidad;
            do{
                cantidad=JOptionPane.showInputDialog("Ingresa la cantidad del producto");
                if(funcion.isANumberNatural(cantidad)){
                   bandera=false; 
                }        
            }while(bandera);
            DefaultTableModel modelo = (DefaultTableModel) TablaFactura.getModel();
            double cant = Double.parseDouble(cantidad);
            modelo.addRow(new Object[]{codigo,nombre,precio,cant,precio*cant});
            actualizarPrecio();
            centrarTabla();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "No se encontro el codigo de barras en la base de datos");
            e.printStackTrace();
        }
    }
    
    public void obtenerProductos(){
        MongoCursor<Document> cursor = coleccion.find().cursor();
        productos=new DefaultTableModel(null,titulos);
        while(cursor.hasNext()){
            Document dato = cursor.next();
            String codigo=dato.getString("ID");
            String nombre=dato.getString("Producto");
            String precio=dato.getString("Precio");
            productos.addRow(new Object[]{codigo,nombre,precio});
        }
    }
    
    private void buscarProducto(){
        String codigo = txtCodigoFact.getText();
        String producto = txtProductoFact.getText();
        DefaultTableModel modelo = new DefaultTableModel(null,titulos);
        if(codigo.equals("")&&!producto.equals("")){
            for(int i=0;i<productos.getRowCount();i++){
                String nombre = productos.getValueAt(i, 1).toString();
                if(nombre.toLowerCase().contains(producto.toLowerCase())){
                    String ID=productos.getValueAt(i, 0).toString();
                    String precio=productos.getValueAt(i, 2).toString();
                    modelo.addRow(new Object[]{ID,nombre,precio});
                }
            }
            Tabla.setModel(modelo);
            mostrarPopup();
        }else if(!codigo.equals("")&&producto.equals("")){
            for(int i=0;i<productos.getRowCount();i++){
                String ID = productos.getValueAt(i, 0).toString();
                if(ID.toLowerCase().contains(codigo.toLowerCase())){
                    String nombre=productos.getValueAt(i, 1).toString();
                    String precio=productos.getValueAt(i, 2).toString();
                    modelo.addRow(new Object[]{ID,nombre,precio});
                }
            }
            Tabla.setModel(modelo);
            mostrarPopup();
        }else if(!codigo.equals("")&&!producto.equals("")){
            for(int i=0;i<productos.getRowCount();i++){
                String nombre=productos.getValueAt(i, 1).toString();
                String ID = productos.getValueAt(i, 0).toString();
                if(ID.toLowerCase().contains(codigo.toLowerCase())&&nombre.toLowerCase().contains(producto.toLowerCase())){
                    String precio=productos.getValueAt(i, 2).toString();
                    modelo.addRow(new Object[]{ID,nombre,precio});
                }
            }
            Tabla.setModel(modelo);
            mostrarPopup();
        }else if(codigo.equals("")&&producto.equals("")){
            menu.setVisible(false);
        }
    }
    
    public void mostrarPopup(){
        centrarTablaPopup();
        menu.removeAll();
        menu.add(new JScrollPane(Tabla));
        menu.repaint();
        menu.revalidate();
        Point punto = txtCodigoFact.getLocationOnScreen();
        int anchoTxt = txtCodigoFact.getWidth()+40;
        menu.setLocation(punto.x+anchoTxt,punto.y);
        menu.setPopupSize(410,150);
        menu.setVisible(true);
    }
    
    public void centrarTablaPopup(){      
        // Crear un renderizador de celdas para centrar los datos
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        // Aplicar el renderizador centrado a todas las columnas de la TablaProducto
        int columnCount = Tabla.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
            Tabla.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        int tam=410;
        Tabla.getColumnModel().getColumn(0).setPreferredWidth(100);
        Tabla.getColumnModel().getColumn(1).setPreferredWidth(tam-100-50);
        Tabla.getColumnModel().getColumn(2).setPreferredWidth(50);
    }
    
    public void centrarTabla(){
        // Crear un renderizador de celdas para centrar los datos
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        // Aplicar el renderizador centrado a todas las columnas de la TablaProducto
        int columnCount = TablaFactura.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
            TablaFactura.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        int tam=699;
        TablaFactura.getColumnModel().getColumn(0).setPreferredWidth(100);
        TablaFactura.getColumnModel().getColumn(1).setPreferredWidth(tam-100-50-80-50);
        TablaFactura.getColumnModel().getColumn(2).setPreferredWidth(50);
        TablaFactura.getColumnModel().getColumn(3).setPreferredWidth(80);
        TablaFactura.getColumnModel().getColumn(4).setPreferredWidth(50);
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JTable TablaFactura;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnConectar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnVenta;
    private javax.swing.JLabel imagen;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTextField txtCantidadFact;
    public static javax.swing.JTextField txtCodigoFact;
    public static javax.swing.JLabel txtPrecio;
    public static javax.swing.JTextField txtProductoFact;
    private javax.swing.JLabel txtSignoDollar;
    // End of variables declaration//GEN-END:variables
}
