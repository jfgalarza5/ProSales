package Vista;

import Modelo.funcionalidades;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import javax.swing.ImageIcon;

public class DescargarLector extends javax.swing.JFrame {
    funcionalidades funcion = new funcionalidades();
    HttpServer server=null;
    
    public DescargarLector() {
        initComponents();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        codigoQR();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        imgQr = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtDescargar = new javax.swing.JLabel();
        fondoCerrar = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Descarga el Lector ProSales");

        imgQr.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        imgQr.setText("  ");

        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Paso 1: Escanea el QR con tu Android.");

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Paso 2: Descarga e instala el App.");

        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Paso 3: Regresa a la pagina anterior.");

        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Y listo, podras escanear los codigos de barra de");

        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("tus podructos de una manera rapida y sencilla.");

        txtDescargar.setForeground(new java.awt.Color(0, 0, 204));
        txtDescargar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtDescargar.setText("¿Cuentas con la App? Click aqui para conectarte");
        txtDescargar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtDescargarMouseClicked(evt);
            }
        });

        fondoCerrar.setBackground(new java.awt.Color(255, 255, 255));
        fondoCerrar.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                fondoCerrarMouseDragged(evt);
            }
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                fondoCerrarMouseMoved(evt);
            }
        });
        fondoCerrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                fondoCerrarMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                fondoCerrarMouseExited(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icono/Cerrar.png"))); // NOI18N

        javax.swing.GroupLayout fondoCerrarLayout = new javax.swing.GroupLayout(fondoCerrar);
        fondoCerrar.setLayout(fondoCerrarLayout);
        fondoCerrarLayout.setHorizontalGroup(
            fondoCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
            .addGroup(fondoCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(fondoCerrarLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        fondoCerrarLayout.setVerticalGroup(
            fondoCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
            .addGroup(fondoCerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(fondoCerrarLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(fondoCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(imgQr, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(txtDescargar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(12, 12, 12)))
                .addGap(36, 36, 36))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(fondoCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(jLabel1)
                .addGap(12, 12, 12)
                .addComponent(imgQr, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(12, 12, 12)
                .addComponent(jLabel3)
                .addGap(12, 12, 12)
                .addComponent(jLabel4)
                .addGap(31, 31, 31)
                .addComponent(jLabel5)
                .addGap(6, 6, 6)
                .addComponent(jLabel6)
                .addGap(49, 49, 49)
                .addComponent(txtDescargar)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void fondoCerrarMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fondoCerrarMouseDragged
        
    }//GEN-LAST:event_fondoCerrarMouseDragged

    private void fondoCerrarMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fondoCerrarMouseMoved
        fondoCerrar.setBackground(Color.red);
    }//GEN-LAST:event_fondoCerrarMouseMoved

    private void fondoCerrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fondoCerrarMouseExited
        fondoCerrar.setBackground(Color.white);
    }//GEN-LAST:event_fondoCerrarMouseExited

    private void fondoCerrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fondoCerrarMouseClicked
        cerrarServidor();
        this.dispose();
    }//GEN-LAST:event_fondoCerrarMouseClicked

    private void txtDescargarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDescargarMouseClicked
        cerrarServidor();
        new ConectarLector();
        dispose();
    }//GEN-LAST:event_txtDescargarMouseClicked
    
    public void codigoQR(){
        String ip = funcion.obtenerMiIP();
        imgQr.setIcon(new ImageIcon(funcion.StringtoQR("http://"+ip+":8080", 134)));
        abrirServidor();
    }
    
    public void cerrarServidor(){
        try{
            server.stop(0);
        }catch(Exception e){}
    }
    
    public void abrirServidor() {
        try{
            // Crear un servidor HTTP en el puerto 8080
            server = HttpServer.create(new InetSocketAddress(8080), 0);

            // Crear un manejador para manejar las solicitudes
            server.createContext("/", new PaginaDescarga());
            server.createContext("/LectorProsales", new AplicacionDescargar());
            // Iniciar el servidor
            server.start();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
     // Implementar el manejador de solicitudes
    static class PaginaDescarga implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            // Obtener la ruta del archivo HTML en tu computadora
            File htmlFile = new File("Sistema/Servidor/PaginaDescarga.html");

            // Verificar si el archivo existe
            if (htmlFile.exists()) {
                // Obtener el contenido del archivo HTML
                byte[] htmlBytes = Files.readAllBytes(htmlFile.toPath());
                // Configurar la respuesta HTTP
                
                t.sendResponseHeaders(200, htmlBytes.length);

                // Obtener el flujo de salida de la respuesta
                OutputStream os = t.getResponseBody();

                // Escribir el contenido del archivo en el flujo de salida
                os.write(htmlBytes);
                // Cerrar el flujo de salida
                os.close();
            } else {
                // Si el archivo no existe, enviar una respuesta 404 (no encontrado)
                String response = "Archivo no encontrado";
                t.sendResponseHeaders(404, response.length());
                OutputStream os = t.getResponseBody();
                os.write(response.getBytes());
                os.close();
            }
        }
    }
    
    static class AplicacionDescargar implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            // Obtener la ruta del archivo HTML en tu computadora
            File archivo = new File("Sistema/Servidor/LectorProsales.apk");

            // Verificar si el archivo existe
            if (archivo.exists()) {
                // Obtener el contenido del archivo HTML
                byte[] apkBytes = Files.readAllBytes(archivo.toPath());
                // Configurar la respuesta HTTP
                t.getResponseHeaders().set("Content-Type", "application/vnd.android.package-archive");
                t.sendResponseHeaders(200, apkBytes.length);
                

                // Obtener el flujo de salida de la respuesta
                OutputStream os = t.getResponseBody();

                // Escribir el contenido del archivo en el flujo de salida
                os.write(apkBytes);
                // Cerrar el flujo de salida
                os.close();
            } else {
                // Si el archivo no existe, enviar una respuesta 404 (no encontrado)
                String response = "Archivo no encontrado";
                t.sendResponseHeaders(404, response.length());
                OutputStream os = t.getResponseBody();
                os.write(response.getBytes());
                os.close();
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel fondoCerrar;
    private javax.swing.JLabel imgQr;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel txtDescargar;
    // End of variables declaration//GEN-END:variables
}
