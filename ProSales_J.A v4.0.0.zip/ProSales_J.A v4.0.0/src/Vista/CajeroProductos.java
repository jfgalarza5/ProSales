package Vista;

import Control.Conexion;
import Modelo.funcionalidades;
import static Vista.Menu.*;
import com.mongodb.client.*;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.*;
import org.bson.Document;

public class CajeroProductos extends javax.swing.JPanel {
    
    funcionalidades funcion=new funcionalidades();
    Conexion con = new Conexion();
    MongoClient mongo = con.crearConexion();
    MongoDatabase base = mongo.getDatabase(con.baseName());
    MongoCollection coleccion = base.getCollection("Producto");
    DefaultTableModel productos;
    String [] titulos =new String[]{"Codigo","Producto","Precio","Tipo"};
    Socket clientSocket=null;
    ServerSocket serverSocket=null;
    
    public CajeroProductos(){
        initComponents();
        obtenerProductos();
        TablaHeader();
        cargarTiposProducto();
        btnVolver.setVisible(true);
        btnVolver.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnVolverMouseClicked(evt);
            }
        });
        btnCajero.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent evt){
                btnCajero(evt);
            }
        });
        btnAdmin.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent evt){
                btnAdmin(evt);
            }
        });
        btnTienda.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent evt){
                btnTienda(evt);
            }
        });
    }
    
    public void btnVolverMouseClicked(java.awt.event.MouseEvent evt){
        funcion.actualizarPanel(new Vista.Cajero());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        txtProducto = new javax.swing.JTextField();
        Scroll = new javax.swing.JScrollPane();
        TablaProducto = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        comboTipo = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        imagen = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        comboPrecio = new javax.swing.JComboBox<>();

        jTextField1.setText("jTextField1");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        txtProducto.setBackground(new java.awt.Color(255, 255, 255));
        txtProducto.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 153)));
        txtProducto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtProductoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtProductoKeyTyped(evt);
            }
        });

        TablaProducto.setBackground(new java.awt.Color(255, 255, 255));
        TablaProducto.setForeground(new java.awt.Color(0, 0, 0));
        TablaProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Producto", "Precio"
            }
        ));
        TablaProducto.setToolTipText("");
        TablaProducto.setGridColor(new java.awt.Color(0, 0, 0));
        TablaProducto.setSelectionBackground(new java.awt.Color(102, 102, 102));
        TablaProducto.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TablaProducto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaProductoMouseClicked(evt);
            }
        });
        Scroll.setViewportView(TablaProducto);

        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Producto:");

        jLabel2.setText(" ");

        jLabel3.setText(" ");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 204));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Porfavor ingrese los detalles de su producto");

        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Codigo:");

        jButton1.setBackground(new java.awt.Color(0, 0, 204));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Conectar Lector ProSales");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel6.setText(" ");

        jLabel8.setText(" ");

        txtCodigo.setBackground(new java.awt.Color(255, 255, 255));
        txtCodigo.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 153)));
        txtCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCodigoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCodigoKeyTyped(evt);
            }
        });

        comboTipo.setBackground(new java.awt.Color(255, 255, 255));
        comboTipo.setForeground(new java.awt.Color(0, 0, 0));
        comboTipo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboTipoItemStateChanged(evt);
            }
        });

        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Tipo:");

        imagen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        imagen.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 0)));

        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Imagen del Producto");

        jLabel10.setText("        ");

        jLabel11.setText("        ");

        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("Ordenar Precios:");

        comboPrecio.setBackground(new java.awt.Color(255, 255, 255));
        comboPrecio.setForeground(new java.awt.Color(0, 0, 0));
        comboPrecio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sin Orden", "Menor Precio", "Mayor Precio" }));
        comboPrecio.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboPrecioItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(222, 222, 222)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(204, 204, 204)
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(27, 27, 27))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(55, 55, 55)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel7))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(comboTipo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(36, 36, 36)
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(35, 35, 35)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(78, 78, 78)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(comboPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(72, 72, 72)
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(Scroll)))
                .addGap(21, 21, 21))
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(30, 30, 30)
                .addComponent(Scroll, javax.swing.GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(49, 49, 49))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel9))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(25, 25, 25)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel1)
                                    .addComponent(txtProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(23, 23, 23)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(comboTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 189, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(comboPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(64, 64, 64)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(19, 19, 19))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void TablaProductoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaProductoMouseClicked
        int fila = TablaProducto.getSelectedRow();
        new Thread(()->imagen.setIcon(new ImageIcon(funcion.imagenProducto(TablaProducto.getValueAt(fila, 1).toString(),100)))).start();
    }//GEN-LAST:event_TablaProductoMouseClicked

    private void txtProductoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtProductoKeyTyped
        
    }//GEN-LAST:event_txtProductoKeyTyped

    private void txtProductoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtProductoKeyReleased
        buscarProductos();
        comboPrecio.setSelectedIndex(0);
    }//GEN-LAST:event_txtProductoKeyReleased

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        cerrarServer();
        new Thread(()->{
            ConectarLector lector = new ConectarLector();
            while(lector.isRunning){
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ex) {
                }
            }
            server();
        }).start();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtCodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodigoKeyReleased
        buscarProductos();
        comboPrecio.setSelectedIndex(0);
    }//GEN-LAST:event_txtCodigoKeyReleased

    private void txtCodigoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodigoKeyTyped
        
    }//GEN-LAST:event_txtCodigoKeyTyped

    private void comboTipoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboTipoItemStateChanged
        buscarProductos();
        comboPrecio.setSelectedIndex(0);
    }//GEN-LAST:event_comboTipoItemStateChanged

    private void comboPrecioItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboPrecioItemStateChanged
        int orden=comboPrecio.getSelectedIndex();
        switch(orden){
            case 0:
                buscarProductos();
                break;
            case 1:
                quickSortTableByColumn(2, true);
                break;
            case 2:
                quickSortTableByColumn(2, false);
                break;
        }
    }//GEN-LAST:event_comboPrecioItemStateChanged
    public void btnCajero(MouseEvent evt){
        cerrarServer();
        funcion.actualizarPanel(new Cajero());
    }
    
    public void btnAdmin(MouseEvent evt){
        cerrarServer();
        funcion.actualizarPanel(new AdminLogin());
    }
    
    public void btnTienda(MouseEvent evt){
        cerrarServer();
        funcion.actualizarPanel(new TiendaDatos());
    }
    
    public void cerrarServer(){
        try{
            if(clientSocket!=null){
                System.out.println("Socket cerrado");
                clientSocket.close();
            }
            if(serverSocket!=null){
                System.out.println("Server cerrado");
                serverSocket.close();
            }
        }catch(IOException x){
        }
    }
    
    public void server() {
        int portNumber = 12345;
        while(true){
            try (ServerSocket serverSocket = new ServerSocket(portNumber)) {
                Socket clientSocket = serverSocket.accept();
                new Thread(() -> handleConnection(clientSocket)).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    private void handleConnection(Socket clientSocket) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {
            String codigo;
            while ((codigo=reader.readLine())!=null) {
                TablaProducto.setModel(productos);
                System.out.println("Mensaje recibido: " + codigo);
                txtCodigo.setText(codigo);
                buscarProductos();
                try{
                    new Thread(()->imagen.setIcon(new ImageIcon(funcion.imagenProducto(TablaProducto.getValueAt(0, 1).toString(),100)))).start();
                }catch(Exception e){}
                comboPrecio.setSelectedIndex(0);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void obtenerProductos(){
        MongoCursor<Document> cursor = coleccion.find().cursor();
        productos=new DefaultTableModel(null,titulos);
        while(cursor.hasNext()){
            Document dato = cursor.next();
            String codigo=dato.getString("ID");
            String nombre=dato.getString("Producto");
            String precio=dato.getString("Precio");
            String tipo=dato.getString("Tipo");
            productos.addRow(new Object[]{codigo,nombre,precio,tipo});
        }
        TablaProducto.setModel(productos);
        centrarTabla();
    }
    
    public void TablaHeader(){
        TablaProducto.getTableHeader().setBackground(Color.BLUE);
        TablaProducto.getTableHeader().setForeground(Color.white);
    }
    
    public void centrarTabla(){      
        // Crear un renderizador de celdas para centrar los datos
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        // Aplicar el renderizador centrado a todas las columnas de la TablaProducto
        int columnCount = TablaProducto.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
            TablaProducto.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        int tam=706;
        TablaProducto.getColumnModel().getColumn(0).setPreferredWidth(50);
        TablaProducto.getColumnModel().getColumn(1).setPreferredWidth(tam-50-30-60);
        TablaProducto.getColumnModel().getColumn(2).setPreferredWidth(30);
        TablaProducto.getColumnModel().getColumn(3).setPreferredWidth(60);
    }
    
    public void buscarProductos(){
        String codigo=txtCodigo.getText();
        String producto=txtProducto.getText();
        String tipo=comboTipo.getSelectedItem().toString();
        DefaultTableModel modelo =new DefaultTableModel(null,titulos);
        
        if(!producto.equals("")&&codigo.equals("")&&tipo.equals("Todo")){
            for(int i=0;i<productos.getRowCount();i++){
                String nombre = productos.getValueAt(i, 1).toString();
                if(nombre.toLowerCase().contains(producto.toLowerCase())){
                    String ID=productos.getValueAt(i, 0).toString();
                    String precio=productos.getValueAt(i, 2).toString();
                    String tipoProducto=productos.getValueAt(i, 3).toString();
                    modelo.addRow(new Object[]{ID,nombre,precio,tipoProducto});
                }
            }
        }
        if(!producto.equals("")&&!codigo.equals("")&&tipo.equals("Todo")){
            for(int i=0;i<productos.getRowCount();i++){
                String nombre = productos.getValueAt(i, 1).toString();
                String ID=productos.getValueAt(i, 0).toString();
                if(nombre.toLowerCase().contains(producto.toLowerCase())
                        &&ID.toLowerCase().contains(codigo.toLowerCase())){
                    String precio=productos.getValueAt(i, 2).toString();
                    String tipoProducto=productos.getValueAt(i, 3).toString();
                    modelo.addRow(new Object[]{ID,nombre,precio,tipoProducto});
                }
            }
        }
        if(!codigo.equals("")&&producto.equals("")&&tipo.equals("Todo")){
            for(int i=0;i<productos.getRowCount();i++){
                String ID = productos.getValueAt(i, 0).toString();
                if(ID.toLowerCase().contains(codigo.toLowerCase())){
                    String nombre=productos.getValueAt(i, 1).toString();
                    String precio=productos.getValueAt(i, 2).toString();
                    String tipoProducto=productos.getValueAt(i, 3).toString();
                    modelo.addRow(new Object[]{ID,nombre,precio,tipoProducto});
                }
            }
        }
        if(!codigo.equals("")&&producto.equals("")&&!tipo.equals("Todo")){
            for(int i=0;i<productos.getRowCount();i++){
                String ID = productos.getValueAt(i, 0).toString();
                String tipoProducto=productos.getValueAt(i, 3).toString();
                
                if(ID.toLowerCase().contains(codigo.toLowerCase())
                        &&tipoProducto.toLowerCase().contains(tipo.toLowerCase())){
                    String nombre=productos.getValueAt(i, 1).toString();
                    String precio=productos.getValueAt(i, 2).toString();
                    modelo.addRow(new Object[]{ID,nombre,precio,tipoProducto});
                }
            }
        }
        if(!tipo.equals("Todo")&&codigo.equals("")&&producto.equals("")){
            for(int i=0;i<productos.getRowCount();i++){
                String tipe = productos.getValueAt(i, 3).toString();
                if(tipe.toLowerCase().contains(tipo.toLowerCase())){
                    String ID=productos.getValueAt(i, 0).toString();
                    String nombre=productos.getValueAt(i, 1).toString();
                    String precio=productos.getValueAt(i, 2).toString();
                    modelo.addRow(new Object[]{ID,nombre,precio,tipe});
                }
            }
        }
        if(!tipo.equals("Todo")&&!codigo.equals("")&&!producto.equals("")){
            for(int i=0;i<productos.getRowCount();i++){
                String tipe = productos.getValueAt(i, 3).toString();
                String nombre=productos.getValueAt(i, 1).toString();
                String ID=productos.getValueAt(i, 0).toString();
                if(tipe.toLowerCase().contains(tipo.toLowerCase())
                        &&nombre.contains(producto.toLowerCase())
                        &&ID.contains(codigo.toLowerCase())){
                    String precio=productos.getValueAt(i, 2).toString();
                    modelo.addRow(new Object[]{ID,nombre,precio,tipe});
                }
            }
        }
        if(tipo.equals("Todo")&&codigo.equals("")&&producto.equals("")){
            obtenerProductos();
            return;
        }
        TablaProducto.setModel(modelo);
        centrarTabla();
    }
    
    public void cargarTiposProducto(){
        comboTipo.addItem("Todo");
        MongoCollection coleccion = base.getCollection("TipoProducto");
        FindIterable<Document> listKeys = coleccion.find();
        Set<String> keys = new HashSet<>();
        for(Document key:listKeys){
            keys.addAll(key.keySet());
        }
        for(String indice:keys){
            if(!indice.equals("_id")){
                comboTipo.addItem(indice);
            }
        }
    }
    
    private void quickSortTableByColumn(int columnIndex, boolean ascending) {
        DefaultTableModel model = (DefaultTableModel) TablaProducto.getModel();
        int rowCount = model.getRowCount();
        Object[][] data = new Object[rowCount][model.getColumnCount()];

        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < model.getColumnCount(); j++) {
                data[i][j] = model.getValueAt(i, j);
            }
        }
        quickSort(data, columnIndex, ascending);

        model.setRowCount(0);
        for (Object[] row : data) {
            model.addRow(row);
        }
    }

    private void quickSort(Object[][] array, int columnIndex, boolean ascending) {
        int low = 0;
        int high = array.length - 1;

        quickSortRecursive(array, low, high, columnIndex, ascending);
    }

    private void quickSortRecursive(Object[][] array, int low, int high, int columnIndex, boolean ascending) {
        if (low < high) {
            int pi = partition(array, low, high, columnIndex, ascending);

            quickSortRecursive(array, low, pi - 1, columnIndex, ascending);
            quickSortRecursive(array, pi + 1, high, columnIndex, ascending);
        }
    }

    private int partition(Object[][] array, int low, int high, int columnIndex, boolean ascending) {
        Object[] pivot = array[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            Comparable<Object> currentValue = (Comparable<Object>) array[j][columnIndex];
            Comparable<Object> pivotValue = (Comparable<Object>) pivot[columnIndex];

            if ((ascending && currentValue.compareTo(pivotValue) <= 0) ||
                    (!ascending && currentValue.compareTo(pivotValue) >= 0)) {
                i++;
                swap(array, i, j);
            }
        }

        swap(array, i + 1, high);
        return i + 1;
    }

    private void swap(Object[][] array, int i, int j) {
        Object[] temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane Scroll;
    public static javax.swing.JTable TablaProducto;
    private javax.swing.JComboBox<String> comboPrecio;
    private javax.swing.JComboBox<String> comboTipo;
    private javax.swing.JLabel imagen;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtProducto;
    // End of variables declaration//GEN-END:variables
}