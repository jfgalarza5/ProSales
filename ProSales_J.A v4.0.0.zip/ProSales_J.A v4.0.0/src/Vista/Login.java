package Vista;

import Control.Conexion;
import Modelo.funcionalidades;
import com.mongodb.client.*;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.bson.Document;

public class Login extends javax.swing.JFrame {

    funcionalidades tool = new funcionalidades();
    Conexion con = new Conexion();
    MongoClient mongo = con.crearConexion();
    
    public Login() {
        this.setUndecorated(true);
        initComponents();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        txtNombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtSesion = new javax.swing.JLabel();
        btnLogin = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        msjContraseña = new javax.swing.JLabel();
        txtPass = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtNombre.setBackground(new java.awt.Color(255, 255, 255));
        txtNombre.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 204)));
        jPanel2.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 140, 196, -1));

        jLabel1.setText("Nombre del Negocio:");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, -1, -1));

        txtSesion.setForeground(new java.awt.Color(0, 0, 255));
        txtSesion.setText("¿Aun no te has registrado? Registrate ahora");
        txtSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtSesionMouseClicked(evt);
            }
        });
        jPanel2.add(txtSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 350, -1, -1));

        btnLogin.setBackground(new java.awt.Color(51, 51, 255));
        btnLogin.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLogin.setForeground(new java.awt.Color(255, 255, 255));
        btnLogin.setText("Iniciar Sesion");
        btnLogin.setBorder(null);
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });
        jPanel2.add(btnLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 290, 156, 38));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 28)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Inicia Sesion");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 590, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagen/degradadoAzul.jpg"))); // NOI18N
        jLabel10.setText("jLabel10");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(-80, 0, 790, 90));

        jLabel7.setText("Contraseña:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, -1, 43));

        msjContraseña.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        msjContraseña.setForeground(new java.awt.Color(255, 0, 0));
        msjContraseña.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        msjContraseña.setText(" ");
        jPanel2.add(msjContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 250, 190, -1));

        txtPass.setBackground(new java.awt.Color(255, 255, 255));
        txtPass.setForeground(new java.awt.Color(0, 0, 0));
        txtPass.setToolTipText("");
        txtPass.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(0, 0, 204)));
        jPanel2.add(txtPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 200, 200, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 587, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtSesionMouseClicked
        new Registro();
        dispose();
    }//GEN-LAST:event_txtSesionMouseClicked

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
        String nombre = txtNombre.getText();
        String Pass = String.valueOf(txtPass.getPassword());

        if(nombre.equals("")||Pass.equals("")){
            JOptionPane.showMessageDialog(null, "Rellene todos los datos");
            return;
        }
        String baseName = nombre.replaceAll("\\s", "");
        MongoIterable<String> databaseNames = mongo.listDatabaseNames();
        MongoCursor<String> cursor = databaseNames.cursor();
        while(cursor.hasNext()){
            if(baseName.equals(cursor.next())){
                MongoDatabase base = mongo.getDatabase(baseName);
                MongoCollection coleccion = base.getCollection("Empresa");
                FindIterable<Document> iterador = coleccion.find(new Document("Pass",Pass));
                for(Document documento:iterador){
                    tool.archivoTxt("Sistema/Base/empresa.txt", baseName);
                    iniciar();
                    dispose();
                    return;
                }
            }
        }
        msjContraseña.setText("Credenciales Invalidas");
    }//GEN-LAST:event_btnLoginActionPerformed
    
    public void iniciar(){
        Menu menu = new Menu();
        //Se habilita la visibilidad del formulario
        menu.setVisible(true);
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel msjContraseña;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JPasswordField txtPass;
    private javax.swing.JLabel txtSesion;
    // End of variables declaration//GEN-END:variables
}
