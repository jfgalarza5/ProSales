package ProSales;

//Se importa el formulario menu del paquete vista
//para poder mostrarlo al momento de ejecutar
import Vista.Registro;

public class ProSales {

    public static void main(String[] args) {
        //Se crea un objeto del formulario menu
        new Vista.PantallaCarga(5);
        new Registro();
    }
}