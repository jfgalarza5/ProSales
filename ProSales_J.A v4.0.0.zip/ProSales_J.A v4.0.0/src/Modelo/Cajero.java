package Modelo;

//Librerias 
import Control.Conexion;
import static Vista.CajeroProductos.TablaProducto;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static Vista.CajeroVenta.*;
import static Vista.CajeroFactura.*;
import static Vista.CajeroCliente.*;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.mongodb.client.*;
import java.awt.image.BufferedImage;
import java.io.FileOutputStream;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import org.bson.Document;

public class Cajero implements Facturacion{
    //Se instancias los objetos que permiten conectar con la base de datos SQL
    Conexion con = new Conexion();
    MongoClient mongo = con.crearConexion();
    MongoDatabase base = mongo.getDatabase(con.baseName());
    funcionalidades funcion = new funcionalidades();
    
    //Declaracion de variables publicas
    double precioNeto;
    int ct;
    String nombreCliente,correoCliente;

    // Declaración de variables privadas
    private String idCliente;
    
    // Registro de cliente
    public void guardarDatos(){
        nombreCliente=txtNombreCliente.getText();
        idCliente=txtCedulaCliente.getText();
        correoCliente=txtCorreoCliente.getText();
        precioNeto = Double.parseDouble(txtDinero.getText());
        MongoCollection<Document> coleccion = base.getCollection("Cliente");
        Document cliente = new Document("Cedula",idCliente);
        MongoCursor<Document> cursor = coleccion.find(cliente).cursor();
        try{
            Document anterior=cursor.next();
            actualizarDatos(anterior,anterior);
            return;
        }catch(Exception e){}
        cliente.append("Nombre", nombreCliente)
               .append("Correo", correoCliente)
                .append("Total Gastado", precioNeto);
        coleccion.insertOne(cliente);
    }
    
    //Metodo que genera una factura
    @Override
    public void crearFactura(){
        ct++;
        try{
            MongoCollection coleccion = base.getCollection("Empresa");
            MongoCursor<Document> cursor = coleccion.find().cursor();
            Document empresa = cursor.next();
            txtCompañia.setText("Empresa: "+empresa.getString("Nombre"));
            txtUbicacion.setText("Ciudad:  "+empresa.getString("Ciudad"));
            txtTelefono.setText("Telef:   "+empresa.getString("Telf"));
            txtFecha.setText("Fecha: "+funcion.fechaHoy());
            txtNumFactura.setText("FACTURA N°"+ct);
            labelCliente.setText(nombreCliente);
            labelCedula.setText(idCliente);
            tablaFacturacion.setModel(TablaFactura.getModel());
            labelSubtotal.setText(String.valueOf(precioNeto));
            labelIva.setText(String.valueOf(iva*precioNeto));
            labelTotal.setText(String.valueOf(iva*precioNeto+precioNeto));
            BufferedImage imagen = funcion.abrirImagen("Sistema/Logo/logo.png");
            logo.setIcon(new ImageIcon(funcion.redimensionar(imagen, 50/(double)imagen.getHeight())));
        }catch(Exception e){}
        
    }

    //Metodo que guarda la factura en PDF
    @Override
    public void guardarFactura(String ubicacion,JTable table){
        Rectangle dimension = new Rectangle(0,0,500,400);
        com.itextpdf.text.Document document = new com.itextpdf.text.Document(dimension);
        System.out.println("Guardado en: "+ubicacion+"\\Factura "+ct+".pdf");
        try{
            PdfWriter.getInstance(document, new FileOutputStream(ubicacion+"\\Factura "+ct+".pdf"));
            PdfPTable pdfTable = new PdfPTable(table.getColumnCount());
            PdfPTable Encabezado = new PdfPTable(4);
            PdfPTable Final = new PdfPTable(2);
            PdfPCell celda = new PdfPCell();
            celda.setHorizontalAlignment(Element.ALIGN_CENTER);
            celda.setVerticalAlignment(Element.ALIGN_CENTER);
            MongoCollection coleccion = base.getCollection("Empresa");
            MongoCursor<Document> cursor = coleccion.find().cursor();
            Document empresa = cursor.next();
            
            BufferedImage imagen = funcion.abrirImagen("Sistema/Logo/logo.png");
            funcion.guardarImagen(funcion.redimensionar(imagen, 50/(double)imagen.getHeight()), "Sistema/Logo/logoFactura.png");
            Image logo = Image.getInstance("Sistema/Logo/logoFactura.png");
            
            document.open();
            
            Font fuenteEncabezado = new Font(Font.FontFamily.TIMES_ROMAN,12);
            Encabezado.setWidthPercentage(100);
            Encabezado.getDefaultCell().setBorder(0);
            Encabezado.setWidths(new float[]{20f,10f,20f,20f});
            
            Font fuenteCuerpo = new Font(Font.FontFamily.TIMES_ROMAN,12);
            Font fuenteEncabezadoTabla = new Font(Font.FontFamily.TIMES_ROMAN,11);
            Font fuenteTabla = new Font(Font.FontFamily.TIMES_ROMAN,9);
            pdfTable.setWidthPercentage(100);
            pdfTable.setWidths(new float[]{20f,55f,15f,15f,15f});
            pdfTable.setHorizontalAlignment(Element.ALIGN_MIDDLE);
            Final.setWidthPercentage(100);
            Final.getDefaultCell().setBorder(0);
            Final.setWidths(new float[]{60f,20f});
            Final.setHorizontalAlignment(Element.ALIGN_LEFT);
            
            Encabezado.addCell(new Paragraph("Empresa: "+empresa.getString("Nombre")+"\n"+
                               "Ciudad:  "+empresa.getString("Ciudad")+"\n"+
                               "Telef:   "+empresa.getString("Telf"),fuenteEncabezado));
            Encabezado.addCell(logo);
            Encabezado.addCell("          ");
            Encabezado.addCell(new Paragraph("FACTURA\n"+"Factura  N°"+ct+"\n"+"Fecha: "+funcion.fechaHoy(),fuenteEncabezado));
            
            document.add(Encabezado);
            
            document.add(new Paragraph(" "));
            document.add(new Paragraph("Cliente: " + nombreCliente+"\nCedula: " + idCliente+
                                       "\n\nDescripcion: ",fuenteCuerpo));
            document.add(new Paragraph(" "));
            for (int i = 0; i < table.getColumnCount(); i++) {
                celda.setPhrase(new Paragraph(table.getColumnName(i),fuenteEncabezadoTabla));
                pdfTable.addCell(celda);
            }
            // Agregar las celdas del JTable a la tabla PDF
            for (int i = 0; i < table.getRowCount(); i++) {
                for (int j = 0; j < table.getColumnCount(); j++) {
                    celda.setPhrase(new Paragraph(table.getValueAt(i, j).toString(),fuenteTabla));
                    pdfTable.addCell(celda);
                }
            }
            // Agregar la tabla PDF al documento            
            document.add(pdfTable);
            document.add(new Paragraph(" "));
            
            Final.addCell("");
            Final.addCell(new Paragraph("Subtotal: " + precioNeto + "$\n"
                                       +"Iva 12%:  " + Math.round(precioNeto * iva*100.0)/100.0 + "$\n"
                                       +"TOTAL: "+(precioNeto + Math.round(precioNeto * iva*100.0)/100.0)+"$",fuenteEncabezadoTabla));
            document.add(Final);
            document.close();
            JOptionPane.showMessageDialog(null, "Factura Guardada");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
    }

    //Metodo que muestra los datos en la tabla Producto
    public void mostrarDatosProducto(){
        //Se crea los titulos de la tabla y el nombre de la base de datos
        String titulos[]={"ID","Producto","Precio"};
        String registro[]=new String [3];
        DefaultTableModel modelo=new DefaultTableModel(null, titulos);
        MongoCollection<Document> coleccion = base.getCollection("Producto");
        MongoCursor<Document> cursor = coleccion.find().iterator();
        
        while(cursor.hasNext()){
            Document dato = cursor.next();
            registro[0]=dato.get("ID").toString();
            registro[1]=dato.get("Producto").toString();
            registro[2]=dato.get("Precio").toString();
            modelo.addRow(registro);
        }
        TablaProducto.setModel(modelo);
    }
    
    public void actualizarDatos(Document anterior,Document montoActual){
        MongoCollection<Document> coleccion = base.getCollection("Cliente");
        double totalGastado = montoActual.getDouble("Total Gastado")+precioNeto;
        Document nuevo = new Document();
        nuevo.append("Cedula", idCliente)
                .append("Nombre", nombreCliente)
               .append("Correo", correoCliente)
                .append("Total Gastado", totalGastado);
        Document update = new Document("$set",nuevo);
        coleccion.updateOne(anterior, update);
    }
    
    //Metodo que agrega datos de producto a la base de datos NoSQL
    public void agregarProducto(){
        try{
            String registro[]=new String [5];
            Document ProductoBuscado=new Document("Producto",txtProductoFact.getText());
            MongoCollection<Document> coleccion = base.getCollection("Producto");
            MongoCursor<Document> cursor = coleccion.find(ProductoBuscado).iterator();
            Document rs = cursor.next();
            double precioNeto = Double.valueOf(rs.getString("Precio"))*Double.valueOf(txtCantidadFact.getText());
            precioNeto=funcion.redondear(precioNeto, 2);
            DefaultTableModel factura = (DefaultTableModel) TablaFactura.getModel();
            registro[0]=rs.getString("ID");
            registro[1]=rs.getString("Producto");
            registro[2]=rs.getString("Precio");
            registro[3]=txtCantidadFact.getText();
            registro[4]=String.valueOf(precioNeto);
            factura.addRow(registro);
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "No se encontro el producto");
        }
            
    }
}