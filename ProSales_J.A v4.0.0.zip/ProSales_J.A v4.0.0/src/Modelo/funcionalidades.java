package Modelo;

import static Vista.Menu.Escritorio;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.nio.file.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Enumeration;
import java.util.regex.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class funcionalidades {
    
    //Metodo para actualizar un Panel
    public void actualizarPanel(JPanel panel){
        panel.setSize(Escritorio.getSize().width, Escritorio.getSize().height);
        Escritorio.removeAll();
        Escritorio.add(panel);
        Escritorio.repaint();
        Escritorio.revalidate();
    }
    //Metodo para copiar y pegar
    public void copiarPegar(String origen,String destino){
        Path original = Paths.get(origen);
        Path copia = Paths.get(destino);
        
        try{
            Files.copy(original,copia,StandardCopyOption.REPLACE_EXISTING);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "No se realizo la copia");
        }
    }
    
    //Date a String
    public String DateAString(Date fecha){
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        return formato.format(fecha);
    }
    
    //String a Date
    public Date StringADate(String fecha){
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        try{
            return formato.parse(fecha);
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    //Borrar Archivo
    public void borrarArchivo(String ruta){
        try{
            Path file = Paths.get(ruta);
            Files.delete(file);
            System.out.println("Bien");
        }catch(Exception e){
            System.out.println(e);
        }
        
    }
    //Metodo para abrir una imagen
    public BufferedImage abrirImagen(String ruta){
        try {
            // Ruta de la imagen en tu PC
            File file = new File(ruta);
            BufferedImage imagen = ImageIO.read(file);
            return imagen;
        } catch (IOException e) {
        }
        return null;
    }
    //Redondear un double n decimales
    public double redondear(double numero,int decimales){
        String formato="#.";
        for(int i=0;i<decimales;i++){
            formato=formato+"#";
        }
        DecimalFormat decimalformat = new DecimalFormat(formato);
        double result = Double.parseDouble(decimalformat.format(numero));
        return result;
    }
    //Metodo que devuelve una imagen redimensionada
    public BufferedImage redimensionar(BufferedImage original,double escala){
        int altura = (int) (original.getHeight()*escala);
        int ancho = (int) (original.getWidth()*escala);
        BufferedImage nueva= new BufferedImage(ancho,altura,original.getType());
        Graphics2D graficos = nueva.createGraphics();
        graficos.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graficos.drawImage(original,0,0,ancho,altura,0,0,original.getWidth(),original.getHeight(),null);
        graficos.dispose();
        return nueva;
    } 
    //Crear un archivo txt con palabras dentro
    public void archivoTxt(String ubicacion, String texto){
        try {
            File archivo = new File(ubicacion);
            FileWriter in = new FileWriter(archivo);
            in.append(texto);
            in.close();
        } catch (IOException ex) {
        } 
    }
    //Metodo que verifica si un Email es valido
    public boolean isValidEmail(String email) {
        String regex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
    //Metodo que permite convertir un arreglo Int a un arreglo String
   public String [] ArrayToString(int [] arrayInt){
       String [] arrayString = new String[arrayInt.length];
       int i=0;
       for(int element:arrayInt){
           arrayString[i]=String.valueOf(element);
           i++;
       }
       return arrayString;
   } 
   
   //Metodo que permite validar si un String es un numero
   public boolean isANumber(String valor){
       boolean bnd=true;
       try{
           Double.valueOf(valor);
           return bnd;
       }catch(NumberFormatException error){
           JOptionPane.showMessageDialog(null, "No es un numero");
           return !bnd;
       }
   }
   
   //Metodo que permite validar si un String es un numero
   public boolean isANumberNatural(String cantidad){
       if(!cantidad.matches("[^.]+")){
            JOptionPane.showMessageDialog(null, "No es un numero natural");
            return false;
        }
        
        if(!isANumber(cantidad)){
            return false;
        }
        return true;
   }
   
   public String [] addArraySting(String [] array, String elemento){
        String [] auxArray = new String[array.length+1];
        System.arraycopy(array, 0, auxArray, 0,array.length);
        auxArray[array.length]=elemento;
        return auxArray;
   }
   
   public int [] addArrayInt(int [] array, int elemento){
       int [] auxArray = new int[array.length+1];
        System.arraycopy(array, 0, auxArray, 0,array.length);
        auxArray[array.length]=elemento;
        return auxArray;
   }
   
   public String fechaHoy(){
        LocalDate hoy = LocalDate.now();
        int dia=hoy.getDayOfMonth();
        int mes=hoy.getMonthValue()-1;
        int año=hoy.getYear();
        String [] meses={"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
        String fechaActual=dia+" de "+meses[mes]+" del "+año;
        return fechaActual;
   }
   
   //Obtener ip del PC
   public String obtenerMiIP(){
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = networkInterfaces.nextElement();
                if (networkInterface.isUp() && !networkInterface.isLoopback()) {
                    Enumeration<InetAddress> addresses = networkInterface.getInetAddresses();
                    while (addresses.hasMoreElements()) {
                        InetAddress address = addresses.nextElement();
                        if (address.getHostAddress().matches("\\d+\\.\\d+\\.\\d+\\.\\d+")) {
                            // Imprime la primera dirección IP que coincide con un formato IPv4
                            String ip=address.getHostAddress();
                            return ip;
                        }
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }        
        return null;
    }
   
   //Generar QR de un String
   public BufferedImage StringtoQR(String text,int tamaño) {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        try {
            BitMatrix bitMatrix = qrCodeWriter.encode(text, BarcodeFormat.QR_CODE, tamaño, tamaño);

            return MatrixToImageWriter.toBufferedImage(bitMatrix);
        } catch (WriterException e) {
            e.printStackTrace();
            return null;
        }
    }
   
    public boolean esNombreCompleto(String cadena) {
        String patronNombreCompleto = "^[A-Za-zÁ-ÿ]+( [A-Za-zÁ-ÿ]+){3}$";
        Pattern patron = Pattern.compile(patronNombreCompleto);
        Matcher matcher = patron.matcher(cadena);
        return matcher.matches();
    }
    
    public static boolean esCedulaEcuatoriana(String idString) {
        String cleanedId = idString.replaceAll("[^0-9]", "");
        if (cleanedId.length() != 10) {
            return false;
        }
        int total = 0;
        for (int i = 0; i < 9; i++) {
            int digit = Character.getNumericValue(cleanedId.charAt(i));
            if (i % 2 == 0) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
            }
            total += digit;
        }

        int checkDigit = (10 - (total % 10)) % 10;
        return Character.getNumericValue(cleanedId.charAt(9)) == checkDigit;
    }
   
   public BufferedImage imagenProducto(String searchTerm, double escala){
        try {
            String url = "https://www.tia.com.ec/catalogsearch/result/?q="+searchTerm.replace(" ", "%20");
            Document document = Jsoup.connect(url).get();
            Element elemento = document.selectFirst("img.product-image-photo");
            if(elemento!=null){
                BufferedImage imagen = ImageIO.read(new URL(elemento.attr("src")));
                return redimensionar(imagen,escala/(double)imagen.getHeight());
            }else{
                System.out.println("No se encontro la imagen");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
   
   public void guardarImagen(BufferedImage imagen,String ruta){
       try{
           File archivo = new File(ruta);
           ImageIO.write(imagen, "png", archivo);
       }catch(Exception e){}
   }
}
