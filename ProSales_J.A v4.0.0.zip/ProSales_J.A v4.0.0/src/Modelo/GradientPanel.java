package Modelo;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import javax.swing.JPanel;

public class GradientPanel extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;

        int width = getWidth();
        int height = getHeight();

        // Color inicial y final del degradado
        Color startColor = new Color(255, 252, 252);
        Color endColor = new Color(220, 221, 252);

        // Punto de inicio y fin para el degradado
        Point startPoint = new Point(0, 0);
        Point endPoint = new Point(0, height);

        // Crear el objeto GradientPaint
        GradientPaint gradientPaint = new GradientPaint(startPoint, startColor, endPoint, endColor);

        // Aplicar el degradado al fondo del JPanel
        g2d.setPaint(gradientPaint);
        g2d.fillRect(0, 0, width, height);
    }
}  
