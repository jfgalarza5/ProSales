package Modelo;

import static Vista.AdminProducto.*;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JOptionPane;
import org.bson.Document;

public class Administrador extends Sistema{
    
    //Sobreescritura 
    @Override
    public void insertarDatosProducto(){
        try{
            MongoCollection<Document> coleccion = base.getCollection("Producto");
            MongoCollection<Document> tipo = base.getCollection("TipoProducto");
            Document documento = new Document();
            double precio = Double.parseDouble(txtPrecio.getText());
            Date vencimiento = CalVencimiento.getDate();
            Date hoy = new Date();
            documento.put("ID", txtCode.getText());
            documento.put("Producto",txtProducto.getText());
            documento.put("Precio",String.valueOf(funcion.redondear(precio, 2)));
            documento.put("Cantidad",txtCantidad.getText());
            if(vence()){
                documento.put("Vencimiento",funcion.DateAString(vencimiento));
                if(hoy.compareTo(vencimiento)>=0){
                    JOptionPane.showMessageDialog(null, "No puedes agregar productos caducados");
                    return;
                }
            }else{
                documento.put("Vencimiento","No vence");
            }
            documento.put("Tipo",comboTipo.getSelectedItem().toString());

            if(validarCampos()){
                return;
            }

            try{
                MongoCursor<Document> cursor=coleccion.find(documento).cursor();
                cursor.next();
                JOptionPane.showMessageDialog(null, "Estos valores ya fueron ingresados");
                txtCode.setText("");
                txtProducto.setText("");
                txtPrecio.setText("");
                return;
            }catch(Exception e){
            }
            MongoCursor<Document> cursor = tipo.find().cursor();
            Document tipos = cursor.next();
            int anterior = tipos.getInteger(comboTipo.getSelectedItem().toString());
            int nuevo = anterior+1;
            Document antiguo = new Document(comboTipo.getSelectedItem().toString(),anterior);
            Document update = new Document("$set",new Document(comboTipo.getSelectedItem().toString(),nuevo));
            tipo.updateOne(antiguo, update);
            coleccion.insertOne(documento);
            mostrarDatosProducto();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void cargarTiposProducto(){
        MongoCollection coleccion = base.getCollection("TipoProducto");
        FindIterable<Document> listKeys = coleccion.find();
        Set<String> keys = new HashSet<>();
        for(Document key:listKeys){
            keys.addAll(key.keySet());
        }
        for(String indice:keys){
            if(!indice.equals("_id")){
                comboTipo.addItem(indice);
            }
        }
    }
}
