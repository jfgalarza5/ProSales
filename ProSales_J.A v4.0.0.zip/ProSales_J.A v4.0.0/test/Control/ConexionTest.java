/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Control;

import com.mongodb.client.MongoClient;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author johng
 */
public class ConexionTest {
    
    public ConexionTest() {
    }

    /**
     * Test of crearConexion method, of class Conexion.
     */
    @Test
    public void testCrearConexion() {
        System.out.println("crearConexion");
        Conexion instance = new Conexion();
        MongoClient expResult = instance.crearConexion();
        MongoClient result = expResult;
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
    
}
