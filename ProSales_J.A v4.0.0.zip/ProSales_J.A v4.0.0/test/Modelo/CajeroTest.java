package Modelo;

import javax.swing.JTable;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author johng
 */
public class CajeroTest {
    
    public CajeroTest() {
    }

    /**
     * Test of guardarDatos method, of class Cajero.
     */
    @Test
    public void testGuardarDatos() {
        System.out.println("guardarDatos");
        Cajero instance = new Cajero();
        instance.guardarDatos();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of crearFactura method, of class Cajero.
     */
    @Test
    public void testCrearFactura() {
        System.out.println("crearFactura");
        Cajero instance = new Cajero();
        instance.crearFactura();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of guardarFactura method, of class Cajero.
     */
    @Test
    public void testGuardarFactura() {
        System.out.println("guardarFactura");
        String ubicacion = "";
        JTable table = null;
        Cajero instance = new Cajero();
        instance.guardarFactura(ubicacion, table);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of mostrarDatosProducto method, of class Cajero.
     */
    @Test
    public void testMostrarDatosProducto() {
        System.out.println("mostrarDatosProducto");
        Cajero instance = new Cajero();
        instance.mostrarDatosProducto();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of agregarProducto method, of class Cajero.
     */
    @Test
    public void testAgregarProducto() {
        System.out.println("agregarProducto");
        Cajero instance = new Cajero();
        instance.agregarProducto();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of insertarDatosCliente method, of class Cajero.
     */
    @Test
    public void testInsertarDatosCliente() {
        System.out.println("insertarDatosCliente");
        Cajero instance = new Cajero();
        instance.guardarDatos();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
